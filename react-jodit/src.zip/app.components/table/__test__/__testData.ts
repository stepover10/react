export const __testData = [
  {
    Header: '이건 테스트 테이블',
    columns: [
      {
        Header: '제목',
        accessor: 'title',
      },
      {
        Header: '글쓴이 ',
        accessor: 'nickname',
      },
    ],
  }
]


export const __testData2 = [
  {
    Header: '번호',
    accessor: 'id',
  },
  {
    Header: '제목',
    accessor: 'title',
  },
  {
    Header: '글쓴이 ',
    accessor: 'nickname',
  },
]