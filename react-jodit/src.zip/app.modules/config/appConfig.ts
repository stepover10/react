export const appConfig = {
  projectName: '커뮤니티'
}