import { createGlobalStyle } from "styled-components";

export const GlobalStyleHeight100 = createGlobalStyle`
  html, body, #__next {
    height: 100%;
  }
`;
